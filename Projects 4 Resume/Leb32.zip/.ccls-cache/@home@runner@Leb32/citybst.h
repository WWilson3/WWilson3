#ifndef CITYBST_H
#define CITYBST_H
#include<string>
#include<iostream>
#include "citynode.h"
class CityBST {
public:
CityNode *root;
CityBST() {
root = nullptr;
}
void insert(CityNode *cityNode) {
  CityNode *currentNode = this->root;
  if (this->root == nullptr) {
    this->root = cityNode;
  }
    while (currentNode != nullptr) {
if (cityNode->data.getPopulation() < currentNode->data.getPopulation()) {
              if (currentNode->left == nullptr) {
               currentNode->left = cityNode;
               currentNode = nullptr;
            }
            else {
               currentNode = currentNode->left;
            }
         }
      if (cityNode->data.getPopulation() > currentNode->data.getPopulation()) {
              if (currentNode->right == nullptr) {
               currentNode->right = cityNode;
               currentNode = nullptr;
            }
            else {
               currentNode = currentNode->right;
            }
         }
}
};
CityNode *search(unsigned int pop) {
  CityNode *newnode = this->root;
  if (newnode == nullptr) {
    return nullptr;
  }
  if (newnode->data.getPopulation() == pop) {
    return newnode;
  }
  while (newnode != nullptr) {
  if (newnode->data.getPopulation() == pop) {
    return newnode;
  }
  else if (newnode->data.getPopulation() < pop) {
    newnode = newnode->right;
  }
  else if (newnode->data.getPopulation() > pop) {
    newnode = newnode->left;
  }
  else if (newnode == nullptr) {
    return nullptr;
  }
  }
};

void printCityBST() {
printCityBSTRecursive(root,0);
}
private:
void printCityBSTRecursive(CityNode *cityNode, int n) {
  if (cityNode == nullptr) {
    return;
  }
  for (int i=0; i<n; i++) {
    cout << " ";
  }
  
    cityNode->data.printInfo();
  
  if (cityNode->left != nullptr) {
    printCityBSTRecursive(cityNode->left, n+1);
  }
  if (cityNode->right != nullptr) {
  printCityBSTRecursive(cityNode->right, n+1);
  }
  
};
};
#endif