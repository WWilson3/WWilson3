#include <iostream>
#include "citybst.h"

City cityarray[] {
  City("Sacremento", 505628),
  City("Eugene", 221452),
  City("Stockton", 323761),
  City("Redding", 90292),
  City("San Diego", 1591688),
  City("Reno", 289485),
  City("Los Angeles", 4340174),
  City("Portland", 730428),
  City("Las Vegas", 711926),
  City("Seattle", 752180),
  City("San Francisco", 871421)
};

CityBST cityBST;

void initCityBSTByInsert(CityBST citybst, City cityarray[], int i) {
  CityNode *newnode = new CityNode(City()); 
  for (int l=0; l<i; l++) {
    newnode = new CityNode(cityarray[i]);
    citybst.insert(newnode);
  }
}

int main() {
  initCityBSTByInsert(cityBST, cityarray, 11);
  cityBST.printCityBST();
  if (cityBST.search(289485) != nullptr) {
  cityBST.search(289485)->data.printInfo();
    }
  else {
    cout << "Not found." << endl;
  }
    if (cityBST.search(782297) != nullptr) {
  cityBST.search(782297)->data.printInfo();
    }
  else {
    cout << "Not found." << endl;
  }
}