#ifndef CITYLIST_H
#define CITYLIST_H
#include<string>
#include <list>
#include "citynode.h"

class CityList {
public:
CityList() {
head = tail = nullptr;
}
void append(CityNode *cityNode) {
  if (this->head == nullptr) {
    this->head = cityNode;
    this->tail = cityNode;
  }
     else{
      this->tail->next = cityNode;
      this->tail = cityNode;
   }
}
void prepend(CityNode *cityNode) {
    if (this->head == nullptr) {
    this->head = cityNode;
    this->tail = cityNode;
  }
  else {
      cityNode->next = this->head;
      this->head = cityNode;
  }
}
void printCityList() {
  CityNode *currentNode = this->head;
  while (currentNode != nullptr) {
    currentNode->data.printInfo();
    currentNode = currentNode->next;
  }
}
CityNode *search(string cityName) {
  CityNode *currentNode = this->head;
  while (currentNode != nullptr) {
    if (currentNode->data.getName() == cityName) {
      return currentNode;
    }
    if (currentNode == nullptr) {
      return nullptr;
    }
  }
  currentNode = currentNode->next;
}
private:
CityNode *head;
CityNode *tail;

};
#endif