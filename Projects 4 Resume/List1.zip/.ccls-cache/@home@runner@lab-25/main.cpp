#include <iostream>
#include "citylist.h"

City cityarray[] {
  City("Los Angeles", 4340174), 
 City("San Diego", 1591688), 
    City("San Francisco", 871421), 
    City("Sacremento", 505628), 
    City("Stockton", 323761), 
    City("Redding", 90292), 
    City("Las Vegas", 711926), 
    City("Reno", 289485), 
    City("Portland", 730428), 
    City("Seatlle", 752180), 
    City("Eugene", 221452)
};

CityList citylist1 = CityList();
CityList citylist2 = CityList();

void initCityListByAppend(CityList citylist, City cityarray[], int size) {
  for (int i=0; i<size; i++) {
    citylist.append(new CityNode(cityarray[i]));
    }
  };

void initCityListByPrepend(CityList citylist, City cityarray[], int size) {
  for (int i=0; i<size; i++) {
    citylist.prepend(new CityNode(cityarray[i]));
    }
  };

int main() {
initCityListByAppend(citylist1, cityarray, 11);
citylist1.printCityList();
initCityListByPrepend(citylist2, cityarray, 11);
citylist2.printCityList();
citylist1.search("Stockton");
}